/**
 * 
 */
package scraper;

/**
 * @author Andy
 *
 */
public class GoogleApp {

	private String name, imgUrl, description, appUrl, developer;

	/**
	 * Default constructor
	 */
	public GoogleApp() {

	}

	/**
	 * Constructor with args
	 * 
	 * @param name
	 * @param imgUrl
	 */
	public GoogleApp(String name, String imgUrl, String description, String appUrl, String developer) {
		this.name = name;
		this.imgUrl = imgUrl;
		this.description = description;
		this.appUrl = appUrl;
		this.developer = developer;
	}

	@Override
	public String toString() {
		return String.format("[%s - %s]", name, imgUrl);
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the imgUrl
	 */
	public String getImgUrl() {
		return imgUrl;
	}

	/**
	 * @param imgUrl the imgUrl to set
	 */
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the appUrl
	 */
	public String getAppUrl() {
		return appUrl;
	}

	/**
	 * @param appUrl the appUrl to set
	 */
	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	/**
	 * @return the developer
	 */
	public String getDeveloper() {
		return developer;
	}

	/**
	 * @param developer the developer to set
	 */
	public void setDeveloper(String developer) {
		this.developer = developer;
	}

}
