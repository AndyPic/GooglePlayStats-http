/**
 * 
 */
package scraper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Andy
 *
 */
public class CleanFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		cleanFile("appdetails.csv");

	}

	/**
	 * Method to read file into array, remove duplicates / clean data
	 * 
	 * @param filename
	 */
	public static void cleanFile(String filename) {

		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(filename));
			Set<String> lines = new HashSet<String>(35000); // maybe should be bigger
			String line;
			while ((line = reader.readLine()) != null) {
				lines.add(line);
			}
			reader.close();
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

			for (String unique : lines) {
				if (!unique.contains("??")) {
					writer.write(unique);
					writer.newLine();
				}

			}
			writer.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
