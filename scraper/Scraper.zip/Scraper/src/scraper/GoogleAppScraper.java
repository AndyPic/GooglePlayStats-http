package scraper;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 */

/**
 * @author Andy
 *
 */
public class GoogleAppScraper {

	protected static List<GoogleApp> googleApps = new ArrayList<>();

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		getAppDetails();

		// fileWriter();

	} // END MAIN

	/**
	 * Method to search google app store for apps, and add names + image URL to
	 * arraylist of apps
	 */
	public static void getAppDetails() {

		Document doc;
		Elements apps;
		String searchCriteria, name, imgUrl, description, appUrl, developer, letter, letterPlus;
		String search = "https://play.google.com/store/search?q=CRITERIA&c=apps";

		// Loop through alphabet
		for (char alphabet = 'a'; alphabet <= 'z'; alphabet++) {

			letter = Character.toString(alphabet);

			// Create search URL for each letter of alphabet
			searchCriteria = search.replaceAll("CRITERIA", letter);

			// Display which letter working on
			System.out.println("\nGetting: " + letter + "...");

			try {

				// Connect to search URL
				doc = Jsoup.connect(searchCriteria).get();

				// Store all app elements
				apps = doc.getElementsByClass("poRVub");

				// Loop through all apps
				for (Element app : apps) {

					try {

						// Display app number
						System.out.printf("%d ", apps.indexOf(app));

						// Get url for app details page
						appUrl = app.attr("abs:href");

						// Connect to individual app page
						doc = Jsoup.connect(appUrl).get();

						// Get app name (without google header)
						name = doc.title().replaceAll(" - Apps on Google Play", "");
						name = cleanString(name);

						// Get image URL
						imgUrl = doc.getElementsByClass("xSyT2c").get(0).child(0).attr("abs:src");

						// Get description
						description = doc.getElementsByClass("DWPxHb").get(0).child(0).child(0).text();
						description = cleanString(description);

						// Get developer
						developer = doc.getElementsByClass("hrTbp R8zArc").get(0).text();
						developer = cleanString(developer);

						// Add new app to list
						if (!developer.contains("??") && !name.contains("??") && !description.contains("????")) {
							googleApps.add(new GoogleApp(name, imgUrl, description, appUrl, developer));
						}

					} catch (IndexOutOfBoundsException e1) {
						e1.printStackTrace();
					} catch (IOException e2) {
						e2.printStackTrace();
					}

				}
			} catch (IOException e) {
				e.printStackTrace();

			}

			for (char alphabet2 = 'a'; alphabet2 <= 'z'; alphabet2++) {
				letterPlus = Character.toString(alphabet) + Character.toString(alphabet2);

				// Create search URL for each letter of alphabet
				searchCriteria = search.replaceAll("CRITERIA", letterPlus);

				// Display which letter working on
				System.out.println("\nGetting: " + letterPlus + "...");

				try {

					// Connect to search URL
					doc = Jsoup.connect(searchCriteria).get();

					// Store all app elements
					apps = doc.getElementsByClass("poRVub");

					// Loop through all apps
					for (Element app : apps) {

						try {

							// Display app number
							System.out.printf("%d ", apps.indexOf(app));

							// Get url for app details page
							appUrl = app.attr("abs:href");

							// Connect to individual app page
							doc = Jsoup.connect(appUrl).get();

							// Get app name (without google header)
							name = doc.title().replaceAll(" - Apps on Google Play", "");
							name = cleanString(name);

							// Get image URL
							imgUrl = doc.getElementsByClass("xSyT2c").get(0).child(0).attr("abs:src");

							// Get description
							description = doc.getElementsByClass("DWPxHb").get(0).child(0).child(0).text();
							description = cleanString(description);

							// Get developer
							developer = doc.getElementsByClass("hrTbp R8zArc").get(0).text();
							developer = cleanString(developer);

							// Add new app to list
							if (!developer.contains("??") && !name.contains("??") && !description.contains("????")) {
								googleApps.add(new GoogleApp(name, imgUrl, description, appUrl, developer));
							}

						} catch (IndexOutOfBoundsException e1) {
							e1.printStackTrace();
						} catch (IOException e2) {
							e2.printStackTrace();
						}

					}
				} catch (IOException e) {
					e.printStackTrace();
				}

				// Write to file for each letter, and wipe array (Prevent memory cap)
				fileWriter();
				googleApps.removeAll(googleApps);
			}
		}

	} // END

	public static void fileWriter() {

		File newFile = new File("appdetails.csv");

		// Create the file
		try {
			if (newFile.createNewFile()) {
				System.out.printf("\nFile (%s) created succesfully.\n", newFile.getName());
			} else {
				System.out.printf("\nFile (%s) already exists.\n", newFile.getName());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Enter the data to the file
		try (FileWriter fw = new FileWriter("appdetails.csv", true)) {

			for (GoogleApp app : googleApps) {
				fw.write(app.getName() + "," + app.getImgUrl() + "," + app.getAppUrl() + "," + app.getDeveloper() + ","
						+ app.getDescription() + "\n");
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Function to replace all the weird characters with utf8 friendly ones
	 */
	public static String cleanString(String string) {

		// Chars to replace

		Map<Character, Character[]> chars = new HashMap<>();

		Character[] a = { '�', '�', '�', '�', '�', '�' };
		chars.put('a', a);
		Character[] A = { '�', '�', '�', '�', '�' };
		chars.put('A', A);
		Character[] e = { '�', '�', '�', '�' };
		chars.put('e', e);
		Character[] E = { '�', '�', '�', '�' };
		chars.put('E', E);
		Character[] i = { '�', '�', '�', '�' };
		chars.put('i', i);
		Character[] I = { '�', '�', '�', '�' };
		chars.put('I', I);
		Character[] o = { '�', '�', '�', '�', '�', '�' };
		chars.put('o', o);
		Character[] O = { '�', '�', '�', '�', '�' };
		chars.put('O', O);
		Character[] u = { '�', '�', '�', '�' };
		chars.put('u', u);
		Character[] U = { '�', '�', '�', '�' };
		chars.put('U', U);
		Character[] other = { '�', '�', '�', '�', '�', '�', '�', '�', '�', '�', ' ' };
		chars.put(' ', other);

		Character[] c = { '�' };
		chars.put('c', c);
		Character[] C = { '�' };
		chars.put('C', C);
		Character[] n = { '�' };
		chars.put('n', n);
		Character[] N = { '�' };
		chars.put('N', N);
		Character[] line = { '�', '�' };
		chars.put('-', line);

		// Replace the chars

		for (Character ch : chars.keySet()) {
			for (int loop = 0; loop < chars.get(ch).length; loop++) {

				string = string.replace(chars.get(ch)[loop], ch);

			}
		}

		string = string.replaceAll(",", "");
		string = string.replaceAll("\"", "'");
		string = string.replaceAll("�", "'");

		// Return the altered String
		return string;
	}

}
